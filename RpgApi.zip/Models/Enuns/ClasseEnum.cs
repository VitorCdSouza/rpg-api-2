namespace RpgApi.Models.Enuns
{
    public enum ClasseEnum
    {
        Cavaleiro = 1,
        Mago = 2,
        Clerigo = 3
    }
}